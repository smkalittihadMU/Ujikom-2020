<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_mapel extends CI_Model {
	public function select_all_mapel() {
		$sql = "SELECT * FROM mapel";

		$data = $this->db->query($sql);

		return $data->result();
	}

	public function select_all() {
		$sql = " SELECT mapel.id AS id, mapel.kode AS kode, mapel.nama AS mapel, kelas.nama AS kelas, jurusan.nama AS jurusan
		FROM mapel, kelas, jurusan WHERE mapel.id_kelas = kelas.id AND mapel.id_jurusan = jurusan.id";

		$data = $this->db->query($sql);

		return $data->result();
	}

	public function select_by_id($id) {
		$sql = "SELECT mapel.id AS id, mapel.kode AS kode, mapel.id_kelas, kelas.nama AS kelas FROM mapel, kelas WHERE mapel.id_kelas = kelas.id  AND mapel.id = '{$id}'";

		$data = $this->db->query($sql);

		return $data->row();
	}

	public function select_by_posisi($id) {
		$sql = "SELECT COUNT(*) AS jml FROM pegawai WHERE id_posisi = {$id}";

		$data = $this->db->query($sql);

		return $data->row();
	}

	public function select_by_kota($id) {
		$sql = "SELECT COUNT(*) AS jml FROM pegawai WHERE id_kota = {$id}";

		$data = $this->db->query($sql);

		return $data->row();
	}

	public function update($data) {
		$sql = "UPDATE mapel SET kode='" .$data['kode'] ."', mapel='" .$data['mapel'] ."', kelas=" .$data['kelas'] .", jurusan='" .$data['jurusan'] ."' WHERE id='" .$data['id'] ."'";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function delete($id) {
		$sql = "DELETE FROM mapel WHERE id='" .$id ."'";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function insert($data) {
		$sql = "INSERT INTO mapel VALUES('','" .$data['kode'] ."','" .$data['mapel'] ."', '" .$data['kelas'] ."''" .$data['jurusan'] ."', )";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function insert_batch($data) {
		$this->db->insert_batch('mapel', $data);
		
		return $this->db->affected_rows();
	}

	public function check_nama($nama) {
		$this->db->where('nama', $nama);
		$data = $this->db->get('mapel');

		return $data->num_rows();
	}

	public function total_rows() {
		$data = $this->db->get('mapel');

		return $data->num_rows();
	}
}

/* End of file M_pegawai.php */
/* Location: ./application/models/M_pegawai.php */