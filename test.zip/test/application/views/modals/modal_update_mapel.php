<div class="col-md-offset-1 col-md-10 col-md-offset-1 well">
  <div class="form-msg"></div>
  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <h3 style="display:block; text-align:center;">Update Mata Pelajaran</h3>

  <form id="form-update-mapel" method="POST">
    <input type="hidden" name="id" value="<?php echo $dataMapel->id; ?>">
    <div class="input-group form-group">
      <span class="input-group-addon" id="sizing-addon2">
        <i class="glyphicon glyphicon-user"></i>
      </span>
      <input type="text" class="form-control" placeholder="Kode Mapel" name="kode" aria-describedby="sizing-addon2" value="<?php echo $dataMapel->kode; ?>">
    </div>
    <div class="input-group form-group">
      <span class="input-group-addon" id="sizing-addon2">
        <i class="glyphicon glyphicon-user"></i>
      </span>
      <input type="text" class="form-control" placeholder="Mata Pelajaran" name="mapel" aria-describedby="sizing-addon2" value="<?php echo $dataMapel->mapel; ?>">
    </div>
    <div class="input-group form-group">
          <span class="input-group-addon" id="sizing-addon2">
            <i class="glyphicon glyphicon-home"></i>
          </span>
          <select name="kelas" class="form-control select2"  aria-describedby="sizing-addon2">
            <?php
            foreach ($dataKelas as $kelas) {
              ?>
              <option value="<?php echo $kelas->id; ?>" <?php if($kelas->id == $dataMapel->id_kelas){echo "selected='selected'";} ?>><?php echo $kelas->nama; ?></option>
              <?php
            }
            ?>
          </select>
    </div>
    <div class="input-group form-group">
          <span class="input-group-addon" id="sizing-addon2">
            <i class="glyphicon glyphicon-home"></i>
          </span>
          <select name="jurusan" class="form-control select2"  aria-describedby="sizing-addon2">
            <?php
            foreach ($dataJurusan as $jurusan) {
              ?>
              <option value="<?php echo $jurusan->id; ?>" <?php if($jurusan->id == $dataMapel->id_jurusan){echo "selected='selected'";} ?>><?php echo $jurusan->nama; ?></option>
              <?php
            }
            ?>
          </select>
        </div>

    <div class="form-group">
      <div class="col-md-12">
          <button type="submit" class="form-control btn btn-primary"> <i class="glyphicon glyphicon-ok"></i> Update Data</button>
      </div>
    </div>
  </form>
</div>