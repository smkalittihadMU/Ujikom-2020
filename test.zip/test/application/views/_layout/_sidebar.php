<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">

    <!-- Sidebar user panel (optional) -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="<?php echo base_url(); ?>assets/img/<?php echo $userdata->foto; ?>" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo $userdata->nama; ?></p>
        <!-- Status -->
        <a href="<?php echo base_url(); ?>assets/#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <ul class="sidebar-menu">
      <li class="header">LIST MENU</li>
      <!-- Optionally, you can add icons to the links -->

      <li <?php if ($page == 'home') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('Home'); ?>">
          <i class="fa fa-home"></i>
          <span>Home</span>
        </a>
      </li>
      
      <li <?php if ($page == 'pegawai') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('Pegawai'); ?>">
          <i class="fa fa-user"></i>
          <span>Data Pegawai</span>
        </a>
      </li>

      <li <?php if ($page == 'posisi') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('Posisi'); ?>">
          <i class="fa fa-briefcase"></i>
          <span>Data Posisi</span>
        </a>
      </li>
      
      <li <?php if ($page == 'kota') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('Kota'); ?>">
          <i class="fa fa-location-arrow"></i>
          <span>Data Kota</span>
        </a>
      </li>
<!-- Data siswa -->
      <li <?php if ($page == 'siswa') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('Siswa'); ?>">
          <i class="fa fa-user"></i>
          <span>Data Siswa</span>
        </a>
      </li>
<!-- Data KElas -->
      <li <?php if ($page == 'kelas') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('Kelas'); ?>">
          <i class="fa fa-user"></i>
          <span>Data Kelas</span>
        </a>
      </li>
<!-- Data Mapel -->
      <li <?php if ($page == 'mapel') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('mapel'); ?>">
          <i class="fa fa-sign-out"></i>
          <span>Data Mapel</span>
        </a>
      </li>
<!-- Data Jurusan -->
      <li <?php if ($page == 'jurusan') {echo 'class="active"';} ?>>
        <a href="<?php echo base_url('jurusan'); ?>">
          <i class="fa fa-sign-out"></i>
          <span>Jurusan</span>
        </a>
      </li>

      <!-- *************************************************************** -->
     <!--  <li class="active treeview">
          <a href="#">
            <i class="fa fa-archive"></i> <span>Manajemen</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="display: none;">
            <li <?php if ($page == 'guru') {echo 'class="active"';} ?>>
              <a href="<?php echo base_url('guru'); ?>">
                <i class="fa fa-user"></i>
                <span>Data Guru</span>
              </a>
            </li>
            <li><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
          </ul>
        </li> -->

    </ul>
    <!-- /.sidebar-menu -->
  </section>
  <!-- /.sidebar -->
</aside>

