<?php
  $no = 1;
  foreach ($dataJurusan as $jrs) {
    ?>
    <tr>
      <td><?php echo $no; ?></td>
      <td><?php echo $jrs->nama; ?></td>
      <td><?php echo $jrs->desk; ?></td>
      <td class="text-center" style="min-width:230px;">
          <button class="btn btn-warning update-dataJurusan" data-id="<?php echo $jrs->id; ?>"><i class="glyphicon glyphicon-repeat"></i> Update</button>
           <button class="btn btn-danger konfirmasiHapus-jurusan" data-id="<?php echo $jrs->id; ?>" data-toggle="modal" data-target="#konfirmasiHapus"><i class="glyphicon glyphicon-remove-sign"></i> Delete</button>
          
      </td>
    </tr>
    <?php
    $no++;
  }
?>